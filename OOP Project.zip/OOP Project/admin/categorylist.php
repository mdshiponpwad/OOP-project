<?php
include_once'inc/header.php';
include_once'inc/sideber.php';
include_once '../classes/Category.php';
$ct = new Category();

$allcat=$ct->AllCategory();
if (isset($_GET['delCat'])) {
    $id = base64_decode($_GET['delCat']);
    $deleteCat = $ct->DeleteCategory($id);
}
?>

<?php
if (!isset($_GET['id'])) {
    echo "<meta http-equiv='refresh' content='0;URL=?id=ahr'/>";
}
?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-12">
                    <span>

                        <?php
                                if (isset($deleteCat)) {
                                ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?= $deleteCat ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php
                                }
                                ?>

                    </span>




                    <div class="card">
                        <h5 class="card-header">Category List</h5>
                        <div class="card-body">




                            <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Category Name</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>


                                <tbody>
                                    <?php
                                                if($allcat){
                                                    $i=0;
                                                    while($row=mysqli_fetch_assoc($allcat)){
                                                        $i++;
                                                        ?>
                                    <tr>
                                        <td><?=$i?></td>
                                        <td><?= $row['catName'] ?></td>
                                        <td>
                                            <a href="catEdit.php?editId=<?= base64_encode($row['catId']) ?>"
                                            class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></a>
                                            <a href="?delCat=<?= base64_encode($row['catId']) ?>"
                                                onclick="return confirm('Are Your Sure to Delete - <?= $row['catName'] ?>')"
                                                class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                                                <a href="" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#myModal-<?=$row['catId']?>"><i class="fas fa-eye"></i></a>
                                                

                                        </td>

                                    </tr>

                                    <?php
                                                    
                                                    }
                                                }
                                                ?>


                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div> <!-- container-fluid -->
    </div>
</div>

<?php 

    $category = $ct->modelData();
    if ($category) {
        while ($catRow = mysqli_fetch_assoc($category)) {
            ?>
<div id="myModal-<?=$catRow['catId']?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="myModalLabel">Modal Heading</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            </button>
        </div>
        <div class="modal-body">
            
            <table class="table table-bordered">
                <tr>
                    <td><label for="">CatName :</label></td>
                    <td><?=$catRow['catName']?></td>
                </tr>
            </table>
                
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-light waves-effect" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary waves-effect waves-light">Save changes</button>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
            <?php
        }
    }

?>

<?php
include_once'inc/footer.php';
?>
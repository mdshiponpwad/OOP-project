<?php
include_once'inc/header.php';
include_once'inc/sideber.php';
include_once '../classes/Category.php';
$ct = new Category();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $catName = $_POST['catName'];

    $catAdd = $ct->AddCategory($catName);
}
?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-xl-6">



                    <span>

                        <?php
                    if (isset($catAdd)) {
                    ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?= $catAdd ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php
                    }
                    ?>

                    </span>
                    <div class="card">
                        <h4 class="card-header">Category Add Form</h4>
                        <div class="card-body">



                            <form action="" method="post">
                                <div class="mb-3">
                                    <label class="form-label">Category Name</label>
                                    <input type="text" name="catName" class="form-control"
                                        placeholder="Category Name" />
                                </div>




                                <div>
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light me-1">
                                            Add Categorry
                                        </button>

                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->


            </div>












        </div> <!-- container-fluid -->
    </div>



    <?php
include_once'inc/footer.php';
?>
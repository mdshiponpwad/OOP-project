<?php
include_once'inc/header.php';
include_once'inc/sideber.php';
include_once '../classes/User.php';
$user = new User();

if(isset($_GET['uid'])){
    $id=$_GET['uid'];
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $update = $user->userUpdate($_POST, $_FILES,$id);
}
?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-xl-6">



                    <span>

                        <?php
                    if (isset($update)) {
                    ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?= $update ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php
                    }
                    ?>

                    </span>
                    <div class="card">
                        <h4 class="card-header">User profile Update Form</h4>
                        <div class="card-body">

                            <?php
                            $getData=$user->UserInfo($id);
                            if($getData){
                                while($row=mysqli_fetch_assoc($getData)){
                                    ?>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label class="form-label">User Name</label>
                                    <input type="text" name="username" class="form-control"
                                        value="<?=$row['username']?>" />
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">User Image</label>
                                    <input type="file" name="image" class="form-control" placeholder="User Image" />
                                    <img src="<?=$row['image']?> " style="width: 200px;" alt="" class="img-thumbnail">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">User Details</label>
                                    <textarea class="form-control" rows="5" name="user_bio" id="classic-editor">
                                            <?=$row['user_bio']?>
                                            </textarea>

                                </div>


                                <div>
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light me-1">
                                            Update Profile
                                        </button>

                                    </div>
                                </div>
                            </form>
                            <?php
                                }

                            }
                            ?>



                        </div>
                    </div>
                </div> <!-- end col -->


            </div>

        </div>
    </div>



    <?php
include_once'inc/footer.php';
?>
<?php 
    include_once '../lib/Session.php';
    Session::init();
    include_once '../lib/Database.php';
    $db = new Database();

    if (isset($_GET['token'])) {
        
        $token = $_GET['token'];
        $query = "SELECT v_token, v_statas FROM tbl_user WHERE v_token='$token'";
        $result = $db->select($query);

        if ($result != false) {
            
            $row = mysqli_fetch_assoc($result);
            if ($row['v_statas'] == 0) {
                
                $click_token = $row['v_token'];
                $update_status = "UPDATE tbl_user SET v_statas='1' WHERE v_token='$click_token'";

                $update_result = $db->update($update_status);

                if ($update_result) {
                    $_SESSION['status'] = "Your Account Has been varified Successfully";
                    header('location:login.php');
                }else {
                    $_SESSION['status'] = "Varification Filed !";
                    header('location:login.php');
                }

            }else {
                $_SESSION['status'] = "This Email Is Already Varified Please Login";
                header('location:login.php');
            }

        }else {
            $_SESSION['status'] = "This Token Does Not Exsist !";
            header('location:login.php');
        }

    }else {
        $_SESSION['status'] = "Not AlloWed";
        header('location:login.php');
    }

?>
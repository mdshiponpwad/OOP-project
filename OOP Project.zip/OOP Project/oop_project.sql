-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 07:13 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oop_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about`
--

CREATE TABLE `tbl_about` (
  `aboutId` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `userDetails` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_about`
--

INSERT INTO `tbl_about` (`aboutId`, `username`, `image`, `userDetails`) VALUES
(1, 'saad', 'upload/48a0d10856.jpg', 'Web developers work independently as freelancers or with company teams to create websites.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(1, 'sports'),
(2, 'Phone'),
(3, 'Tv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comtId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(70) NOT NULL,
  `message` text NOT NULL,
  `admin_reply` text DEFAULT NULL,
  `update_date` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comtId`, `userId`, `postId`, `name`, `email`, `website`, `message`, `admin_reply`, `update_date`, `status`, `create_time`) VALUES
(9, 1, 1, 'asasa', 'mdshiponpwad1@gmail.com', 'NULL', 'not good', 'okk', 'May 06, 2023', 1, '2023-05-05 20:36:01'),
(25, 1, 1, 'we4rwer', 'mdshiponpwad@gmail.com', 'NULL', 'not good', NULL, '', 0, '2023-05-06 06:35:36'),
(26, 1, 1, 'we4rwer', 'mdsaadahmed2018@gmail.com', 'NULL', 'last commnet', 'why', 'May 06, 2023', 1, '2023-05-06 06:35:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `contactId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`contactId`, `name`, `email`, `phone`, `message`, `create_time`) VALUES
(2, 'asasa', 'dfsfggf@gmail.com', '123456', 'rgettr', '2023-05-06 16:31:11'),
(3, 'asasa', 'dfsfggf@gmail.com', '123456', 'rgettr', '2023-05-06 16:33:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logo`
--

CREATE TABLE `tbl_logo` (
  `logoId` int(11) NOT NULL,
  `logoName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_logo`
--

INSERT INTO `tbl_logo` (`logoId`, `logoName`) VALUES
(1, 'PWAD');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `postId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `catId` int(11) NOT NULL,
  `imageOne` varchar(255) NOT NULL,
  `disOne` text NOT NULL,
  `imageTwo` varchar(255) NOT NULL,
  `disTwo` text NOT NULL,
  `postType` tinyint(4) NOT NULL DEFAULT 1,
  `tags` varchar(100) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`postId`, `userId`, `title`, `catId`, `imageOne`, `disOne`, `imageTwo`, `disTwo`, `postType`, `tags`, `status`, `create_time`) VALUES
(1, 1, 'Pakistan register first ODI series win over New Zealand in 12 years', 1, 'upload/8f757ddd3c.jpg', 'TPakistan registered their first one-day international series win over New Zealand in 12 years with a hard-fought 26-run victory in the third match in Karachi on Wednesday.\r\n\r\nImam-ul-Haq scored a 107-ball 90 while Babar Azam made a 62-ball 54 for his 26th ODI half-century to guide Pakistan to 287-6 in their 50 overs.\r\n\r\nOpener Tom Blundell hit 65 for New Zealand while debutant Cole McConchie struck an undefeated 45-ball 64 but the visitors were bowled out for 261 in 49.1 overs.', 'upload/898259791d.jpg', 'Tom Latham, who made 45, and Mark Chapman (13) added 40 for the fourth wicket but pacer Naseem Shah bowled Chapman with a beautiful delivery before Latham was cleaned up by Wasim.\r\n\r\nMcConchie tied valiantly to snatch a victory for New Zealand, smashing two sixes and six fours but ran out of partners.', 1, 'Cricket', 1, '2023-05-05 03:27:27'),
(3, 3, 'post1', 1, 'upload/7b3238d7f1.jpg', 'asasass', 'upload/35b5885286.jpg', 'dds', 1, 'saad', 1, '2023-05-05 17:06:58'),
(4, 1, 'gf', 2, 'upload/fdecd028d9.jpg', 'bvv', 'upload/7bf6c426af.jpg', 'hg', 2, 'h', 1, '2023-05-06 10:16:06'),
(5, 1, 'ghgf', 1, 'upload/39ef605c7e.jpg', 'yuhty', 'upload/ed157c37a8.jpg', 'ryt', 2, 'vndfjkl', 1, '2023-05-06 10:19:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `sId` int(11) NOT NULL,
  `twtter` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `insta` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`sId`, `twtter`, `facebook`, `insta`, `youtube`) VALUES
(1, 'https://twitter.com/i/flow/login', 'https://www.facebook.com/', 'https://www.instagram.com/', 'https://www.youtube.com/');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userId` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `v_token` varchar(55) NOT NULL,
  `image` varchar(255) NOT NULL,
  `user_bio` text DEFAULT NULL,
  `v_statas` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userId`, `username`, `email`, `phone`, `password`, `v_token`, `image`, `user_bio`, `v_statas`, `create_at`) VALUES
(1, 'Md Shipon', 'mdshiponpwad@gmail.com', '123456', 'e10adc3949ba59abbe56e057f20f883e', 'a1cfcd8c423f17fbcbd91fb33e130e09', 'upload/e4f1a7b4bd.jpg', 'Web Developer', 1, '2023-05-02 11:44:19'),
(3, 'saad', 'mdsaadahmed2018@gmail.com', '01571254978', 'e10adc3949ba59abbe56e057f20f883e', '6ecae739840da07c905bd25dbbcba69a', 'upload/6e32537908.gif', '', 1, '2023-05-04 14:16:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_about`
--
ALTER TABLE `tbl_about`
  ADD PRIMARY KEY (`aboutId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comtId`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `tbl_logo`
--
ALTER TABLE `tbl_logo`
  ADD PRIMARY KEY (`logoId`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`postId`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`sId`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_about`
--
ALTER TABLE `tbl_about`
  MODIFY `aboutId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comtId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `contactId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_logo`
--
ALTER TABLE `tbl_logo`
  MODIFY `logoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `postId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `sId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

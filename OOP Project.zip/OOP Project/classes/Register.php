<?php 

    include_once '../lib/Database.php';
    include_once '../helpers/Format.php';

    include_once '../PHPmailer/PHPMailer.php';
    include_once '../PHPmailer/SMTP.php';
    include_once '../PHPmailer/Exception.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    class Register{

        public $db;
        public $fr;

        public function __construct()
        {
            $this->db = new Database();
            $this->fr = new Format();
        }


        public function AddUser($data){

            function sendemail_varifi($name, $email, $v_token){
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->SMTPAuth = true;

                $mail->Host  = 'smtp.gmail.com';                                  
                $mail->Username = 'mdshiponpwad@gmail.com';                     
                $mail->Password  = 'qudobdsniceabgtw';
                
                $mail->SMTPSecure = 'tls';
                $mail->Port =587;
                
                $mail->setFrom('mdshiponpwad@gmail.com', $name);
                $mail->addAddress($email);

                $mail->isHTML(true);                                
                $mail->Subject = 'Email Varification From PWAD';

                $email_template = "
                <h2>You have register with pwad</h2>
                <h5>Verify your email address to login please click the link below</h5>
                <a href='http://localhost/OOP%20Project/admin/verifi-email.php?token=$v_token'>Click Here</a>
            ";

                $mail->Body = $email_template;
                $mail->send();
                //echo "Email has benn sent"; 
            }

            $name = $this->fr->validation($data['name']);
            $email = $this->fr->validation($data['email']);
            $phone = $this->fr->validation($data['phone']);
            
            $password =$this->fr->validation(md5($data['password']));
            $v_token = md5(rand());
           
            if (empty($name) || empty($email) || empty($phone) || empty($password)) {
                $error = "Fild Must Not Be Empty";
                return $error;
            }else {
                $e_query = "SELECT * FROM tbl_user WHERE email='$email'";
                $check_email = $this->db->select($e_query);

                if ($check_email > '0') {
                    $error = "This Email Is Alrady Exisit";
                    return $error;
                    header("location:register.php");
                }else {
                    $insert_query = "INSERT INTO tbl_user(username, email, phone, password, v_token) VALUES('$name', '$email', '$phone', '$password', '$v_token')";

                    $insert_row = $this->db->insert($insert_query);

                    if ($insert_row) {
                        sendemail_varifi($name, $email, $v_token);
                        $success = "Resistration Successfull. Please check your email inbox for varifi email";
                        return $success;
                    }else {
                        $error = "Registration Failed";
                        return $error;
                    }
                }
            }

        }

    }

?>